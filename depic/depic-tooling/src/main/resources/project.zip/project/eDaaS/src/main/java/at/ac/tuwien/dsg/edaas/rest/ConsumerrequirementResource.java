/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package at.ac.tuwien.dsg.edaas.rest;


import at.ac.tuwien.dsg.depic.common.entity.runtime.DataPartitionRequest;
import at.ac.tuwien.dsg.edaas.config.Configuration;


import at.ac.tuwien.dsg.edaas.requirement.DataAssetRequest;
import at.ac.tuwien.dsg.edaas.requirement.service.DataAssetRequestHandler;
import at.ac.tuwien.dsg.edaas.utils.JAXBUtils;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.PathParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.GET;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.xml.bind.JAXBException;

/**
 * REST Web Service
 *
 * @author bolobala
 */
@Path("dataasset")
public class ConsumerrequirementResource {
    
    @Context
    private UriInfo context;
    
    /**
     * Creates a new instance of ConsumerrequirementResource
     */
    public ConsumerrequirementResource() {
    }
    
    /**
     * Retrieves representation of an instance of at.ac.tuwien.dsg.edaas.ConsumerrequirementResource
     * @return an instance of java.lang.String
     */
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String getXml() {
        //TODO return proper representation object
        Configuration config = new Configuration();
        
        return "eDaaS: " + config.getConfig("DATA.ASSET.LOADER.IP") + "-" + config.getConfig("ORCHESTRATOR.IP");
    }
    
    /**
     * PUT method for updating or creating an instance of ConsumerrequirementResource
     * @param content representation for the resource
     * @return an HTTP response with content of the updated or created resource.
     */
    @PUT
    @Path("request")
    @Consumes(MediaType.APPLICATION_XML)
    @Produces(MediaType.APPLICATION_XML)
    public String requestDataAsset(String dataAssetRequestXML) {
        
        Logger.getLogger(ConsumerrequirementResource.class.getName()).log(Level.INFO, "Recieved: " + dataAssetRequestXML);
        DataAssetRequest  dataAssetRequest=null;
        try {
            dataAssetRequest = JAXBUtils.unmarshal(dataAssetRequestXML, DataAssetRequest.class);
        } catch (JAXBException ex) {
            Logger.getLogger(ConsumerrequirementResource.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        Logger.getLogger(ConsumerrequirementResource.class.getName()).log(Level.INFO, "Data Asset: " + dataAssetRequest.getDataAssetID());
        
        DataAssetRequestHandler dataAssetRequestHandler = new DataAssetRequestHandler();
        dataAssetRequestHandler.processDataAssetRequest(dataAssetRequest);
        
        return "";
    }
    
    
    @PUT
    @Path("get")
    @Consumes(MediaType.APPLICATION_XML)
    @Produces(MediaType.APPLICATION_XML)
    public String getDataPartition(String dataPartitionRequest) {
        
        Logger.getLogger(ConsumerrequirementResource.class.getName()).log(Level.INFO, "Recieved: " + dataPartitionRequest);
        DataPartitionRequest dataPartition = null;
        
        try {
            dataPartition = JAXBUtils.unmarshal(dataPartitionRequest, DataPartitionRequest.class);
        } catch (JAXBException ex) {
            Logger.getLogger(ConsumerrequirementResource.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        String log =  "Data Asset: " + dataPartition.getDataAssetID() +"; Partition: " + dataPartition.getPartitionID();
        Logger.getLogger(ConsumerrequirementResource.class.getName()).log(Level.INFO,log);
        
        DataAssetRequestHandler dataAssetRequestHandler = new DataAssetRequestHandler();
        String daXML = dataAssetRequestHandler.loadDataPartition(dataPartition);
        
        return daXML;
    }
    
    @PUT
    @Path("conf/dataassetloaderip")
    @Consumes(MediaType.APPLICATION_XML)
    @Produces(MediaType.APPLICATION_XML)
    public String configDataAssetLoaderIP(String ip) {
        
        Configuration config = new Configuration();
        config.setProperties("DATA.ASSET.LOADER.IP", ip);
        
        return "";
    }
    
    
    @PUT
    @Path("conf/orchestratorip")
    @Consumes(MediaType.APPLICATION_XML)
    @Produces(MediaType.APPLICATION_XML)
    public String configOrchestratorIP(String ip) {
        
        Configuration config = new Configuration();
        config.setProperties("ORCHESTRATOR.IP", ip);
        
        return "";
    }
    
    
}
