/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package at.ac.tuwien.dsg.edaas.requirement.service;

import at.ac.tuwien.dsg.common.entity.eda.ElasticDataAsset;
import at.ac.tuwien.dsg.common.entity.eda.ElasticState;
import at.ac.tuwien.dsg.common.entity.eda.ElasticStateSet;
import at.ac.tuwien.dsg.common.entity.eda.MetricCondition;
import at.ac.tuwien.dsg.common.entity.eda.da.DataAsset;
import at.ac.tuwien.dsg.common.entity.eda.da.DataPartitionRequest;
import at.ac.tuwien.dsg.common.entity.eda.ep.MonitoringSession;
import at.ac.tuwien.dsg.common.utils.IOUtils;
import at.ac.tuwien.dsg.common.utils.JAXBUtils;

import at.ac.tuwien.dsg.edaas.config.Configuration;
import at.ac.tuwien.dsg.edaas.requirement.ConsumerRequirement;
import at.ac.tuwien.dsg.edaas.requirement.DataAssetRequest;
import at.ac.tuwien.dsg.edaas.requirement.TemplateConstraint;
import at.ac.tuwien.dsg.edaas.utils.RestfulWSClient;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.bind.JAXBException;

/**
 *
 * @author Jun
 */
public class DataAssetRequestHandler {

    /**
     * get data asset from DataAssetFunctionManagement, and store in EDA
     * Repository
     */
    public String processDataAssetRequest(DataAssetRequest dataAssetRequest) {


         String noOfDataPartitions = requestToCopyDataAsset(dataAssetRequest);

        
//        List<String> expectedElasticStates = findExpectedElasticState(dataAssetRequest);
//
//        Configuration configuration = new Configuration();
//        String edaasName = configuration.getConfig("EDAAS.NAME");
//
//        MonitoringSession monitoringSession = new MonitoringSession(dataAssetRequest.getCustomerID(), edaasName, dataAssetRequest.getDataAssetID(), expectedElasticStates);
//
//        startMonitoringServices(monitoringSession);

        return noOfDataPartitions;
    }
    
    

    
    private String requestToCopyDataAsset(DataAssetRequest dataAssetRequest){
        
        Configuration configuration  = new Configuration();
        String ip = configuration.getConfig("DATA.ASSET.LOADER.IP");
        String port = configuration.getConfig("DATA.ASSET.LOADER.PORT");
        String resource = configuration.getConfig("DATA.ASSET.LOADER.RESOURCE.COPY");
      
        
        System.out.println("IP: " + ip);
        System.out.println("PORT: " + port);
        System.out.println("RESOURSE: " + resource);
  
        String edaasName = configuration.getConfig("EDAAS.NAME");
        
        DataPartitionRequest request = new DataPartitionRequest(edaasName, dataAssetRequest.getCustomerID(), dataAssetRequest.getDataAssetID(), "");
        
        String requestXML="";
        
        try {
            requestXML = JAXBUtils.marshal(request, DataPartitionRequest.class);
        } catch (JAXBException ex) {
            Logger.getLogger(DataAssetRequestHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        RestfulWSClient ws = new RestfulWSClient(ip, port, resource);
        String noOfPartition = ws.callPutMethod(requestXML);
        return noOfPartition;
    }
    
    
    
    private List<String> findExpectedElasticState(DataAssetRequest dataAssetRequest){
        
        
        ConsumerRequirement consumerRequirement = dataAssetRequest.getConsumerRequirement();    
        ConstraintConverter constraintConverter = new ConstraintConverter();
        List<TemplateConstraint> listOfConstraints = constraintConverter.getListOfConstraints(consumerRequirement);
        logTemplateConstraint(listOfConstraints);
        
 
        
        ElasticDataAsset eda = getEDAModel(dataAssetRequest.getDataAssetID());
        ElasticStateSet elasticStateSet = eda.getElasticStateSet();
        
        List<String> expectedElasticStateIDs = new ArrayList<String>();
        
        List<ElasticState> finalEStateSet = elasticStateSet.getFinalElasticStateSet();
        
        
        
        
        System.out.println("Find Expected Elastic State.");
        
        
        
        
        
        for (ElasticState elasticState : finalEStateSet) {

            if (isExpectedEState(listOfConstraints, elasticState)){
                
                expectedElasticStateIDs.add(elasticState.geteStateID());
                System.out.println("eDaaS: expected eState ID: " + elasticState.geteStateID());
                
            }   
        }
        
        return expectedElasticStateIDs;
        
        
    }
    
    private ElasticDataAsset getEDAModel(String dataAssetID){
        
        Configuration configuration  = new Configuration();
        String ip = configuration.getConfig("ORCHESTRATOR.IP");
        String port = configuration.getConfig("ORCHESTRATOR.PORT");
        String resource = configuration.getConfig("ORCHESTRATOR.EDA.RESOURCE");
        
        RestfulWSClient ws = new RestfulWSClient(ip, port, resource);
        String xml = ws.callPutMethod(dataAssetID);
        
        ElasticDataAsset eda = null;
        
        try {
            eda = JAXBUtils.unmarshal(xml, ElasticDataAsset.class);
        } catch (JAXBException ex) {
            Logger.getLogger(DataAssetRequestHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return eda;
    }
    
    
    private void startMonitoringServices(MonitoringSession monitoringSession){
        
        String mSessionXML="";
        try {
            mSessionXML = JAXBUtils.marshal(monitoringSession, MonitoringSession.class);
        } catch (JAXBException ex) {
            Logger.getLogger(DataAssetRequestHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        Configuration configuration  = new Configuration();
        String ip = configuration.getConfig("ORCHESTRATOR.IP");
        String port = configuration.getConfig("ORCHESTRATOR.PORT");
        String resource = configuration.getConfig("ORCHESTRATOR.MONITORING.RESOURCE");
        
        RestfulWSClient ws = new RestfulWSClient(ip, port, resource);
        ws.callPutMethod(mSessionXML);
    }
    
    public String getDataAssetPartition(DataPartitionRequest dataPartition){
        
        String dataPartitionXML="";
        
        try {
            dataPartitionXML = JAXBUtils.marshal(dataPartition, DataPartitionRequest.class);
        } catch (JAXBException ex) {
            Logger.getLogger(DataAssetRequestHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        // request monitor data asset
        monitorDataAssetPartition(dataPartitionXML);
        
        // load data partition
        String daXML = loadDataPartition(dataPartitionXML);
      
        return daXML;
    }
    
    private void monitorDataAssetPartition(String dataPartitionXML){
        Configuration configuration  = new Configuration();
        String ip = configuration.getConfig("DATA.ASSET.LOADER.IP");
        String port = configuration.getConfig("DATA.ASSET.LOADER.PORT");
        String resource = configuration.getConfig("DATA.ASSET.LOADER.RESOURCE.GET");
        
        RestfulWSClient ws = new RestfulWSClient(ip, port, resource);
        
        ws.callPutMethod(dataPartitionXML);
    }
    
    
    public String loadDataPartition(String dataPartitionXML){
        Configuration configuration  = new Configuration();
        String ip = configuration.getConfig("DATA.ASSET.LOADER.IP");
        String port = configuration.getConfig("DATA.ASSET.LOADER.PORT");
        String resource = configuration.getConfig("DATA.ASSET.LOADER.RESOURCE.GET");
        
        RestfulWSClient ws = new RestfulWSClient(ip, port, resource);
        
        String daXML = ws.callPutMethod(dataPartitionXML);
//        
//        DataAsset da=null;
//        try {
//            da = JAXBUtils.unmarshal(rs, DataAsset.class);
//        } catch (JAXBException ex) {
//            Logger.getLogger(DataAssetRequestHandler.class.getName()).log(Level.SEVERE, null, ex);
//        }
        return daXML;
    }
    
    
    private boolean isExpectedEState(List<TemplateConstraint> listOfConstraints, ElasticState elasticState){
        
        boolean rs = true;
        List<MetricCondition> listOfMetricConditions = elasticState.getListOfConditions();
        System.out.println("");
        System.out.println("isExpectedEState ...");
        logElasticState(elasticState);
       
       
        
        
        
        for (MetricCondition metricCondition : listOfMetricConditions) {

            try {
                String metricCondtionXML = JAXBUtils.marshal(metricCondition, MetricCondition.class);
                System.out.println("METRIC CONDITION: \n" +metricCondtionXML);
            } catch (JAXBException ex) {
                Logger.getLogger(DataAssetRequestHandler.class.getName()).log(Level.SEVERE, null, ex);
            }
          //  if (!metricCondition.getMetricName().equals("cost")) {
                TemplateConstraint constraint = findMatchConstraint(listOfConstraints, metricCondition.getMetricName());

                log1MetricCondition(metricCondition);
                log1Constraint(constraint);

                if (!((metricCondition.getLowerBound() >= constraint.getMinValue()) && (metricCondition.getUpperBound() <= constraint.getMaxValue()))) {
                    rs = false;
                    System.out.println("FAIL METRIC");
                    break;
                } else {
                    
                }

            

            /*
            if(!(constraint.getMinValue()>=metricCondition.getLowerBound()) || !(constraint.getMaxValue()<=metricCondition.getUpperBound())){
                rs = false;
                break;
            }
            */
            
        }
        
        
        return rs;
    }
    
    private TemplateConstraint findMatchConstraint(List<TemplateConstraint> listOfConstraints,String metricName){
        
        
        
        TemplateConstraint templateConstraint = null;
        for (TemplateConstraint constraint : listOfConstraints) {
            
            System.out.println("findMatchConstraint: Compare: " + constraint.getConstraintName()+" vs " + metricName);
            
            if (constraint.getConstraintName().equals(metricName)){
                templateConstraint = constraint;
                break;
            }
        }
        return templateConstraint;
    }
    
    private void logTemplateConstraint(List<TemplateConstraint> listOfConstraints){
        
        for (TemplateConstraint constraint : listOfConstraints) {
            System.out.println("Name: " + constraint.getConstraintName());
            System.out.println("Min: " + constraint.getMinValue());
            System.out.println("Max: " + constraint.getMaxValue());
        }
        
    }
    
    private void logElasticState(ElasticState elasticState){
        
        System.out.println("ElasticState ID: " + elasticState.geteStateID());
        
        List<MetricCondition> listOfConditions = elasticState.getListOfConditions();
        
        for (MetricCondition condition : listOfConditions) {
            System.out.println("Condition ID: " + condition.getConditionID());
            System.out.println("Metric Name: " + condition.getMetricName());
            System.out.println("Lower Bound: " + condition.getLowerBound());
            System.out.println("Upper Bound: " + condition.getUpperBound());
     
            
        }
        
        
    }
    
    
    private void log1MetricCondition(MetricCondition metricCondition){
        System.out.println("log1MetricCondition ...");
        System.out.println("Condition ID: " + metricCondition.getConditionID());
            System.out.println("Metric Name: " + metricCondition.getMetricName());
            System.out.println("Lower Bound: " + metricCondition.getLowerBound());
            System.out.println("Upper Bound: " + metricCondition.getUpperBound());
    }
    
    private void log1Constraint(TemplateConstraint constraint){
        System.out.println("log1Constraint ...");
        System.out.println("Name: " + constraint.getConstraintName());
            System.out.println("Min: " + constraint.getMinValue());
            System.out.println("Max: " + constraint.getMaxValue());
    }
    
    
}
