/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package at.ac.tuwien.dsg.edaas.requirement.service;




import at.ac.tuwien.dsg.depic.common.entity.eda.dataasset.DataAsset;
import at.ac.tuwien.dsg.depic.common.entity.runtime.DBType;
import at.ac.tuwien.dsg.depic.common.entity.runtime.DataPartitionRequest;
import at.ac.tuwien.dsg.depic.common.entity.runtime.MonitoringSession;
import at.ac.tuwien.dsg.depic.common.utils.JAXBUtils;
import at.ac.tuwien.dsg.depic.common.utils.RestfulWSClient;
import at.ac.tuwien.dsg.edaas.config.Configuration;
import at.ac.tuwien.dsg.edaas.requirement.ConsumerRequirement;
import at.ac.tuwien.dsg.edaas.requirement.DataAssetRequest;
import at.ac.tuwien.dsg.edaas.requirement.TemplateConstraint;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.bind.JAXBException;


/**
 *
 * @author Jun
 */
public class DataAssetRequestHandler {
    
    /**
     * get data asset from DataAssetFunctionManagement, and store in EDA
     * Repository
     */
    public void processDataAssetRequest(DataAssetRequest dataAssetRequest) {
        
        // requestToCopyDataAsset(dataAssetRequest);
        
        
        
        MonitoringSession monitoringSession = new MonitoringSession(
                                                                    dataAssetRequest.getCustomerID(),
                                                                    dataAssetRequest.getDataAssetID(),
                                                                    dataAssetRequest.getDataAssetID(),
                                                                    DBType.MYSQL, null);
        startMonitoringServices(monitoringSession);
        
        
        //
        //        MySqlDataAssetStore msdas = new MySqlDataAssetStore();
        //
        //        msdas.getDataPartition(monitoringSession.getDataAssetID(), "0");
        
        
    }
    
    public String getLastestDataAssetWindow(DataAssetRequest dataAssetRequest){
        MonitoringSession monitoringSession = new MonitoringSession(
                                                                    dataAssetRequest.getCustomerID(),
                                                                    dataAssetRequest.getDataAssetID(),
                                                                    dataAssetRequest.getDataAssetID(),
                                                                    DBType.MYSQL, null);
        
        
        return loadDataPartition(monitoringSession);
        
    }
    
    private String requestToCopyDataAsset(DataAssetRequest dataAssetRequest) {
        
        Configuration configuration = new Configuration();
        String ip = configuration.getConfig("DATA.ASSET.LOADER.IP");
        String port = configuration.getConfig("DATA.ASSET.LOADER.PORT");
        String resource = configuration.getConfig("DATA.ASSET.LOADER.RESOURCE.COPY");
        
        System.out.println("IP: " + ip);
        System.out.println("PORT: " + port);
        System.out.println("RESOURSE: " + resource);
        
        String edaasName = configuration.getConfig("EDAAS.NAME");
        
        DataPartitionRequest request = new DataPartitionRequest(edaasName, dataAssetRequest.getCustomerID(), dataAssetRequest.getDataAssetID(), "");
        
        String requestXML = "";
        
        try {
            requestXML = JAXBUtils.marshal(request, DataPartitionRequest.class);
        } catch (JAXBException ex) {
            Logger.getLogger(DataAssetRequestHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        RestfulWSClient ws = new RestfulWSClient(ip, port, resource);
        String noOfPartition = ws.callPutMethod(requestXML);
        return noOfPartition;
    }
    
    
    private void startMonitoringServices(MonitoringSession monitoringSession) {
        
        
        Configuration configuration = new Configuration();
        String ip = configuration.getConfig("ORCHESTRATOR.IP");
        String port = configuration.getConfig("ORCHESTRATOR.PORT");
        String resource = configuration.getConfig("ORCHESTRATOR.MONITORING.RESOURCE");
        
        RestfulWSClient ws = new RestfulWSClient(ip, port, resource);
        
        String monitoringSessionXML = "";
        
        try {
            monitoringSessionXML = JAXBUtils.marshal(monitoringSession, MonitoringSession.class);
        } catch (JAXBException ex) {
            Logger.getLogger(DataAssetRequestHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        ws.callPutMethod(monitoringSessionXML);
    }
    
    public String loadDataPartition(MonitoringSession monitoringSession) {
        Configuration configuration = new Configuration();
        String ip = configuration.getConfig("DATA.ASSET.LOADER.IP");
        String port = configuration.getConfig("DATA.ASSET.LOADER.PORT");
        String resource = configuration.getConfig("DATA.ASSET.LOADER.RESOURCE.GET");
        
        RestfulWSClient ws = new RestfulWSClient(ip, port, resource);
        
        String monitoringSessionXML = "";
        
        try {
            monitoringSessionXML = JAXBUtils.marshal(monitoringSession, MonitoringSession.class);
        } catch (JAXBException ex) {
            Logger.getLogger(DataAssetRequestHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        String daXML = ws.callPutMethod(monitoringSessionXML);
        
        
        
        return daXML;
    }
    
    
    
    
}
