/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package at.ac.tuwien.dsg.orchestrator.demo;

import at.ac.tuwien.dsg.common.rest.QualityEvaluatorREST;

import at.ac.tuwien.dsg.orchestrator.properties.PropertiesConfiguration;
import at.ac.tuwien.dsg.orchestrator.properties.VMCluster;
import java.util.List;

/**
 *
 * @author Jun
 */
public class App2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        
     //   QualityEvaluatorREST qualityEvaluatorREST = new QualityEvaluatorREST();
        //    qualityEvaluatorREST.callQualityEvaluator("102;0");
        
      /*  
        PropertiesConfiguration propertiesConfiguration = new PropertiesConfiguration();
            List<VMCluster> ls =  propertiesConfiguration.getProperties();
            
            VMCluster vmCluster = ls.get(0);
        
   
            ResponseTimeRest responseTimeRest = new ResponseTimeRest(vmCluster.getIp(), vmCluster.getPort());
            responseTimeRest.updateResponseTime("1", 0, 512,1232123);
    */
              
              }
    
}
