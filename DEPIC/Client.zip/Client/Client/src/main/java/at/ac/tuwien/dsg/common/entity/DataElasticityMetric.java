/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package at.ac.tuwien.dsg.common.entity;

/**
 *
 * @author Jun
 */
public class DataElasticityMetric {
    String name;
    Double value;
    
}
